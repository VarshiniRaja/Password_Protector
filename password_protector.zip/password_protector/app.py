from flask import Flask, request, jsonify, render_template
import openpyxl
import os

app = Flask(__name__)

# Path to your Excel file
EXCEL_FILE = 'passwords.xlsx'

# Ensure Excel file exists with the required headers
if not os.path.exists(EXCEL_FILE):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["Name", "Password", "Description", "Code"])  # Adding Code column
    wb.save(EXCEL_FILE)

# Function to check if the code exists in Excel
def find_code_in_excel(code):
    wb = openpyxl.load_workbook(EXCEL_FILE)
    ws = wb.active
    for row in ws.iter_rows(values_only=True):
        # Convert the code to string and strip any spaces
        if str(row[3]).strip() == str(code).strip():
            return True
    return False


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/verify_code', methods=['POST'])
def verify_code():
    data = request.json
    code = data.get('code')

    if not code:
        return jsonify({"message": "Please provide a code!"}), 400

    if find_code_in_excel(code):
        return jsonify({"message": "Code verified. You can now save or retrieve a password."}), 200
    else:
        return jsonify({"message": "Invalid code! Please try again."}), 400

@app.route('/save', methods=['POST'])
def save_password():
    data = request.json
    name = data.get('name')
    password = data.get('password')
    description = data.get('description')
    code = data.get('code')

    if not (name and password and description and code):
        return jsonify({"message": "Please provide name, password, description, and code."}), 400

    # Save to Excel
    wb = openpyxl.load_workbook(EXCEL_FILE)
    ws = wb.active
    ws.append([name, password, description, code])
    wb.save(EXCEL_FILE)

    return jsonify({"message": "Password saved successfully!"}), 200

@app.route('/retrieve', methods=['POST'])
def retrieve_password():
    data = request.json
    name = data.get('name')
    code = data.get('code')

    if not (name and code):
        return jsonify({"message": "Please provide name and code."}), 400

    wb = openpyxl.load_workbook(EXCEL_FILE)
    ws = wb.active
    for row in ws.iter_rows(values_only=True):
        if row[0] == name and row[3] == code:
            return jsonify({"password": row[1]}), 200

    return jsonify({"error": "No password found for the given name and code."}), 404

if __name__ == '__main__':
    app.run(debug=True)
